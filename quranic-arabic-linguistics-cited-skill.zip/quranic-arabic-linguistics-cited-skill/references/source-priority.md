# Source Priority for Qur'anic Arabic Linguistics

This file tells the assistant which source layers to prefer and how to cite them.

## 1. Primary text

### Qur'an
Use Qur'anic usage first:
- exact ayah,
- neighboring context,
- cross-verse occurrences,
- repeated phrase patterns,
- surah-level rhetorical structure.

Citation object:
```json
{
  "source_type": "quran_cross_reference",
  "work": "Qur'an",
  "entry_or_section": "Surah:Ayah",
  "claim_supported": "usage/context/parallel expression"
}
```

## 2. Early and classical lexicons

Use these for root, lemma, semantic field, and near-synonym contrast.

### Early / foundational
- al-Khalīl b. Aḥmad, **Kitāb al-ʿAyn**
- Ibn Fāris, **Maqāyīs al-Lughah**
- al-Jawharī, **al-Ṣiḥāḥ**
- al-Azharī, **Tahdhīb al-Lughah**
- Ibn Sīdah, **al-Muḥkam wa-l-Muḥīṭ al-Aʿẓam**

### Qur'an-focused / semantic
- al-Rāghib al-Aṣfahānī, **al-Mufradāt fī Gharīb al-Qurʾān**
- Abū Hilāl al-ʿAskarī, **al-Furūq al-Lughawiyyah**

### Large consolidating lexicons
- Ibn Manẓūr, **Lisān al-ʿArab**
- al-Zabīdī, **Tāj al-ʿArūs**
- Edward William Lane, **Arabic-English Lexicon**

## 3. Sarf / morphology references

Use for pattern, derivation, form meaning, and morphological nuance.

- Sībawayh, **al-Kitāb**
- Ibn Jinnī, **al-Khaṣāʾiṣ**
- Ibn Jinnī, **al-Munṣif**
- Ibn Mālik, **Alfiyyah**
- Ibn ʿAqīl, **Sharḥ Ibn ʿAqīl**
- al-Raḍī, **Sharḥ al-Shāfiyah**
- modern teaching references only as secondary aids.

For Qur'anic token-level morphology:
- Quranic Arabic Corpus,
- MASAQ or other reviewed Qur'anic morphology datasets,
- manually verified classical parsing.

Dataset output must be marked as dataset evidence, not as classical authority.

## 4. Iʿrāb / syntax / nahw sources

Use these for Qur'anic parsing, syntactic alternatives, qirāʾāt effects, and grammar disputes.

### Core i'rab
- al-Naḥḥās, **Iʿrāb al-Qurʾān**
- al-ʿUkbarī, **al-Tibyān fī Iʿrāb al-Qurʾān**
- Makkī b. Abī Ṭālib, **Mushkil Iʿrāb al-Qurʾān**
- al-Samīn al-Ḥalabī, **al-Durr al-Maṣūn fī ʿUlūm al-Kitāb al-Maknūn**

### Tafsir with strong grammar
- Abū Ḥayyān, **al-Baḥr al-Muḥīṭ**
- al-Zamakhsharī, **al-Kashshāf**

### Modern structured aids
- Maḥmūd Ṣāfī, **al-Jadwal fī Iʿrāb al-Qurʾān wa-Ṣarfihi wa-Bayānihi**
- Muḥyī al-Dīn Darwīsh, **Iʿrāb al-Qurʾān al-Karīm wa-Bayānuh**

Mark modern aids as useful organization, not as final authority when older sources disagree.

## 5. Balagha / rhetoric sources

Use for rhetorical devices and meaning effects.

- ʿAbd al-Qāhir al-Jurjānī, **Dalāʾil al-Iʿjāz**
- ʿAbd al-Qāhir al-Jurjānī, **Asrār al-Balāghah**
- al-Zamakhsharī, **al-Kashshāf**
- Fakhr al-Dīn al-Rāzī, **Mafātīḥ al-Ghayb**
- Ibn ʿĀshūr, **al-Taḥrīr wa-l-Tanwīr**
- al-Suyūṭī, **al-Itqān fī ʿUlūm al-Qurʾān**
- al-Zarkashī, **al-Burhān fī ʿUlūm al-Qurʾān**

## 6. Tafsir sources

Use tafsir for meaning, interpretive options, theological implications, and passage-level discourse.

### Early and classical
- Muqātil b. Sulaymān, **Tafsīr Muqātil**
- al-Ṭabarī, **Jāmiʿ al-Bayān**
- Ibn Qutaybah, **Gharīb al-Qurʾān** and **Taʾwīl Mushkil al-Qurʾān**
- al-Māwardī, **al-Nukat wa-l-ʿUyūn**
- al-Wāḥidī, **al-Wasīṭ / al-Basīṭ / Asbāb al-Nuzūl**
- al-Zamakhsharī, **al-Kashshāf**
- Fakhr al-Dīn al-Rāzī, **Mafātīḥ al-Ghayb**
- al-Qurṭubī, **al-Jāmiʿ li-Aḥkām al-Qurʾān**
- Ibn Kathīr, **Tafsīr al-Qurʾān al-ʿAẓīm**
- Abū Ḥayyān, **al-Baḥr al-Muḥīṭ**
- al-Ālūsī, **Rūḥ al-Maʿānī**
- Ibn ʿĀshūr, **al-Taḥrīr wa-l-Tanwīr**

### How to use tafsir
- First identify what the mufassir actually says.
- Then identify whether his point is lexical, syntactic, rhetorical, theological, historical, or argumentative.
- Do not treat tafsir as morphology unless the tafsir explicitly discusses the form or parsing.

## 7. Modern academic / secondary sources

Use these as secondary, not replacement for Arabic sources.

Examples:
- Nicolai Sinai, **Key Terms of the Qur'an**
- The Encyclopaedia of the Qur'an
- academic articles on Qur'anic semantics, rhetoric, and late antique context.

Always label this layer as:
`modern_academic`.

## 8. Citation hierarchy

Prefer exact, source-provided locators in this order:

1. book + volume + page,
2. book + root/entry,
3. book + surah/ayah,
4. book + chapter/section,
5. source known but locator missing,
6. source family only.

Never fabricate exact locators.
Use `locator_needed` where necessary.

## 9. Evidence grading

### Strong evidence
- direct Arabic quote from source,
- exact locator,
- agrees with Qur'anic usage,
- supported by multiple source layers.

### Medium evidence
- source known but locator missing,
- grammar rule is standard but not cited,
- source-supported inference.

### Weak evidence
- modern paraphrase only,
- unsupported memory,
- possible but not contextually preferred,
- AI-generated explanation without source anchor.

## 10. Required citation fields for k-maps

For ingestion, each citation should include:

```json
{
  "citation_id": "string",
  "source_type": "lexicon | irab | tafsir | balagha | grammar | quran_cross_reference | modern_academic | user_provided_text",
  "author": "string",
  "work": "string",
  "edition": "string|null",
  "volume": "string|null",
  "page": "string|null",
  "entry_or_section": "string|null",
  "quote_ar": "string|null",
  "quote_en": "string|null",
  "claim_supported": "string",
  "certainty": "verified | locator_needed | needs_check"
}
```
