# k-maps Qur'anic Linguistics JSON Schema Guide

This is a practical shape, not a strict JSON Schema file.

## Top-level object

```json
{
  "analysis_id": "string",
  "scope": {},
  "arabic_text": {},
  "segmentation": [],
  "morphology": [],
  "syntax_irab": [],
  "lexicon_semantics": [],
  "balagha": [],
  "tafsir_links": [],
  "translation_layers": {},
  "citations": [],
  "confidence_summary": {},
  "review_drills": []
}
```

## Scope

```json
{
  "surah": 78,
  "surah_name_ar": "النبأ",
  "ayah_from": 1,
  "ayah_to": 2,
  "phrase": "عَمَّ يَتَسَاءَلُونَ عَنِ النَّبَإِ الْعَظِيمِ",
  "scope_type": "passage"
}
```

## Morphology item

```json
{
  "token_id": "78:1:1",
  "surface": "عَمَّ",
  "normalized": "عَمَّ",
  "components": ["عن", "ما"],
  "root": null,
  "lemma": "عن + ما",
  "pattern": null,
  "pos": "preposition + interrogative particle",
  "features": {
    "case": null,
    "mood": null,
    "number": null,
    "gender": null,
    "person": null,
    "definiteness": null
  },
  "notes": "Contraction of عن + ما; alif of ما omitted after preposition in common Qur'anic/Arabic usage.",
  "citations": ["src-001"],
  "confidence": "high"
}
```

## Syntax / i'rab item

```json
{
  "unit_id": "syn-001",
  "text": "عَمَّ",
  "irab_ar": "عن: حرف جر، وما: اسم استفهام مجرور بعن، والجار والمجرور متعلقان بالفعل يتساءلون.",
  "irab_en": "ʿan is a preposition; mā is an interrogative pronoun governed by ʿan; the prepositional phrase relates to the verb yatasāʾalūn.",
  "governor": "يتساءلون",
  "role": "prepositional complement of inquiry",
  "alternatives": [],
  "meaning_effect": "The opening asks about the object/topic of their mutual questioning.",
  "citations": ["src-002"],
  "confidence": "high"
}
```

## Lexicon / semantics item

```json
{
  "lexeme_id": "lex-naba",
  "surface": "النَّبَإ",
  "root": "ن ب أ",
  "lemma": "نَبَأ",
  "semantic_core": "a report/news item of weight and consequence; in Qur'anic usage often a significant report tied to truth, warning, or revelation.",
  "near_synonyms": [
    {
      "term": "خَبَر",
      "contrast": "خبر is broader report/information; نبأ is contextually more weighty and consequential when supported by sources."
    }
  ],
  "source_basis": "lexicon + Qur'anic context + tafsir",
  "citations": ["src-003", "src-004"],
  "confidence": "medium"
}
```

## Balagha item

```json
{
  "device_id": "bal-001",
  "arabic_device": "استفهام للتشويق والتهويل",
  "location": "عَمَّ يَتَسَاءَلُونَ",
  "description_en": "The passage opens with a question about their questioning, creating suspense and magnifying the matter before naming it.",
  "translation_effect": "A fluent translation should preserve the dramatic opening, not flatten it into a plain information question.",
  "citations": ["src-005"],
  "confidence": "medium"
}
```

## Tafsir link

```json
{
  "tafsir_id": "taf-001",
  "source": "Ibn ʿĀshūr, al-Taḥrīr wa-l-Tanwīr",
  "view": "Opening by interrogating the act of questioning creates tashwīq and tahwīl.",
  "classification": ["balagha", "passage_structure", "tafsir"],
  "effect_on_translation": "The opening should sound suspenseful and grave.",
  "citations": ["src-005"],
  "confidence": "medium"
}
```

## Translation layers

```json
{
  "word_by_word": "About what are they asking one another? About the great nabaʾ.",
  "structure_preserving": "What is it that they are asking one another about? About the tremendous report.",
  "fluent_english": "What are they asking one another about? About the momentous news.",
  "tafsir_aware": "What is this matter they keep questioning one another about? It is the tremendous announcement.",
  "notes": [
    {
      "term": "النَّبَأ",
      "note": "News/report is too flat if the context and sources indicate a weighty, consequential announcement."
    }
  ]
}
```

## Citation item

```json
{
  "citation_id": "src-001",
  "source_type": "irab",
  "author": "al-ʿUkbarī",
  "work": "al-Tibyān fī Iʿrāb al-Qurʾān",
  "edition": null,
  "volume": null,
  "page": null,
  "entry_or_section": "Sūrat al-Nabaʾ 78:1",
  "quote_ar": null,
  "quote_en": null,
  "claim_supported": "Parsing of عَمَّ as عن + ما and its syntactic relation.",
  "certainty": "locator_needed"
}
```

## Confidence summary

```json
{
  "overall": "medium",
  "reasons": [
    "Morphology is standard/high confidence.",
    "Some classical citations are source-level but require exact edition/page locators.",
    "Tafsir effects should be verified against supplied source text before final ingestion."
  ]
}
```
