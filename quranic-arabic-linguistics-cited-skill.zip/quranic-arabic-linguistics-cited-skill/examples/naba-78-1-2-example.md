# Example: Sūrat al-Nabaʾ 78:1–2

Arabic:

```arabic
عَمَّ يَتَسَاءَلُونَ
عَنِ النَّبَإِ الْعَظِيمِ
```

## 1. Scope

- Surah: al-Nabaʾ, 78
- Ayah: 1–2
- Passage function: opening question, suspense, and magnification of the topic.

## 2. Segmentation

```text
عَمَّ = عن + ما
يَتَسَاءَلُونَ = they mutually ask one another
عَنِ = about
النَّبَإِ = the momentous report/news
الْعَظِيمِ = tremendous/great
```

## 3. Morphology

| token | root | lemma | pattern | POS | notes |
|---|---|---|---|---|---|
| عَمَّ | — | عن + ما | — | preposition + interrogative | contraction of عن + ما |
| يَتَسَاءَلُونَ | س أ ل | تَسَاءَلَ | تَفَاعَلَ | imperfect verb | Form VI, mutual questioning |
| عَنِ | — | عن | — | preposition | repeated/clarifying relation |
| النَّبَإِ | ن ب أ | نَبَأ | فَعَل | noun | definite, genitive after عن |
| الْعَظِيمِ | ع ظ م | عَظِيم | فعيل | adjective | follows النبأ in case/definiteness |

## 4. Syntax / iʿrāb

- `عَمَّ`: originally `عن ما`; `عن` is a preposition and `ما` is interrogative. The phrase is connected to `يَتَسَاءَلُونَ`.
- `يَتَسَاءَلُونَ`: imperfect verb; wāw is the subject.
- `عَنِ النَّبَإِ`: prepositional phrase. It explains/specifies the object of questioning.
- `الْعَظِيمِ`: adjective for `النَّبَإِ`, matching it in genitive case, definiteness, and masculine singular form.

## 5. Lexicon note: النبأ

Do not translate `النَّبَأ` automatically as ordinary "news" without checking source and context.

A careful translation may use:
- "the momentous news"
- "the tremendous report"
- "the grave announcement"

depending on tafsir and rhetorical context.

## 6. Balagha

The passage opens by asking about their questioning before naming the subject. This creates:
- تشويق: suspense/anticipation,
- تهويل: magnification of the matter,
- تعظيم: marking the topic as weighty.

## 7. Translation layers

### Word-by-word
About what are they asking one another? About the great nabaʾ.

### Structure-preserving
What is it that they are asking one another about? About the tremendous report.

### Fluent English
What are they asking one another about? About the momentous news.

### Tafsir-aware
What is this matter they keep questioning one another about? It is the tremendous announcement.

### Translation note
"News" is fluent but may be too flat. `نَبَأ` in this context should carry weight, consequence, and seriousness.

## 8. Example citations object

```json
[
  {
    "citation_id": "src-naba-lex-001",
    "source_type": "lexicon",
    "author": "al-Rāghib al-Aṣfahānī",
    "work": "al-Mufradāt fī Gharīb al-Qurʾān",
    "edition": null,
    "volume": null,
    "page": null,
    "entry_or_section": "root ن ب أ",
    "quote_ar": null,
    "quote_en": null,
    "claim_supported": "نَبَأ carries the sense of a significant report, not merely ordinary news.",
    "certainty": "locator_needed"
  },
  {
    "citation_id": "src-naba-tafsir-001",
    "source_type": "tafsir",
    "author": "Ibn ʿĀshūr",
    "work": "al-Taḥrīr wa-l-Tanwīr",
    "edition": null,
    "volume": null,
    "page": null,
    "entry_or_section": "Sūrat al-Nabaʾ 78:1–2",
    "quote_ar": null,
    "quote_en": null,
    "claim_supported": "The opening question creates suspense and magnification before the matter is named.",
    "certainty": "locator_needed"
  }
]
```

## 9. Example k-maps JSON

```json
{
  "analysis_id": "qr-78-1-2-demo",
  "scope": {
    "surah": 78,
    "surah_name_ar": "النبأ",
    "ayah_from": 1,
    "ayah_to": 2,
    "scope_type": "passage"
  },
  "arabic_text": {
    "uthmani": "عَمَّ يَتَسَاءَلُونَ ۝ عَنِ النَّبَإِ الْعَظِيمِ"
  },
  "translation_layers": {
    "word_by_word": "About what are they asking one another? About the great nabaʾ.",
    "structure_preserving": "What is it that they are asking one another about? About the tremendous report.",
    "fluent_english": "What are they asking one another about? About the momentous news.",
    "tafsir_aware": "What is this matter they keep questioning one another about? It is the tremendous announcement."
  },
  "confidence_summary": {
    "overall": "medium",
    "note": "Morphology is high confidence; exact source locators should be verified before production ingestion."
  }
}
```
